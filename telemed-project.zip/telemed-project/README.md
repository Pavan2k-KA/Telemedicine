# Telemedicine Platform (Docker + Compose)

This repository contains a simple telemedicine web app (React frontend + Express backend + Postgres) with Docker and docker-compose configuration for local development.

## Quick start (Docker)

1. Build and start everything:
```bash
docker-compose up --build
```

2. The frontend will be available at: http://localhost:5173
The backend API at: http://localhost:4000/api
Postgres exposed on 5432 (user/postgres, pass/postgres)

3. Initialize DB schema (run migration SQL inside the running db container):
```bash
# from repo root
docker exec -i $(docker ps -qf "ancestor=postgres:15-alpine") psql -U postgres -d telemed_db -f /app/backend/migrations/20250901_initial.sql
```
Alternatively, copy the migrations file and run psql locally.

## Notes
- This setup is for local development only. For production, use secrets, managed DB, and httpOnly cookies for JWT.
- The frontend production image serves bundled assets via nginx; compose maps port 5173 -> nginx:80 for convenience.
