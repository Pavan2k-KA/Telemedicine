import { Routes, Route, useNavigate } from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import Signup from './pages/Signup'
import PatientDashboard from './pages/PatientDashboard'
import DoctorDashboard from './pages/DoctorDashboard'
import Booking from './pages/Booking'
import Header from './components/Header'
import { useEffect } from 'react'
import { setAuth } from './api'

export default function App(){
  useEffect(()=>{
    const token = localStorage.getItem('token')
    setAuth(token)
  },[])

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/signup" element={<Signup/>} />
          <Route path="/patient" element={<PatientDashboard/>} />
          <Route path="/doctor" element={<DoctorDashboard/>} />
          <Route path="/booking/:doctorId" element={<Booking/>} />
        </Routes>
      </main>
    </div>
  )
}
