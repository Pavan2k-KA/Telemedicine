import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import API from '../api'

export default function Booking(){
  const { doctorId } = useParams()
  const [doctor, setDoctor] = useState(null)
  const [date, setDate] = useState('')
  const [time, setTime] = useState('09:00')
  const [msg, setMsg] = useState('')
  const nav = useNavigate()

  useEffect(()=>{
    API.get('/doctors').then(r=> {
      const d = r.data.doctors.find(x=> String(x.id) === String(doctorId))
      setDoctor(d)
    })
  },[doctorId])

  async function submit(e){
    e.preventDefault()
    try{
      const scheduled_at = new Date(`${date}T${time}`)
      await API.post('/appointments',{ doctor_id: doctorId, scheduled_at, notes: msg })
      nav('/patient')
    }catch(err){
      alert('Booking failed: ' + (err?.response?.data?.message || ''))
    }
  }

  if(!doctor) return <div>Loading...</div>

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-xl font-bold">Book with Dr. {doctor.name}</h2>
      <form onSubmit={submit} className="space-y-3 mt-4">
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} className="w-full border p-2 rounded" required />
        <input type="time" value={time} onChange={e=>setTime(e.target.value)} className="w-full border p-2 rounded" required />
        <textarea value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Notes (optional)" className="w-full border p-2 rounded" />
        <button className="w-full bg-blue-600 text-white py-2 rounded">Confirm Booking</button>
      </form>
    </div>
  )
}
