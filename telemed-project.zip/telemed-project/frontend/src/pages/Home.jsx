import { useEffect, useState } from 'react'
import API from '../api'
import { Link } from 'react-router-dom'

export default function Home(){
  const [doctors, setDoctors] = useState([])
  useEffect(()=>{ API.get('/doctors').then(r=> setDoctors(r.data.doctors)).catch(()=>{}) },[])

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Find a doctor</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {doctors.map(d=> (
          <div key={d.id} className="bg-white p-4 rounded shadow">
            <h2 className="text-xl font-semibold">{d.name}</h2>
            <p className="text-sm">{d.specialization} — {d.years_experience} yrs</p>
            <p className="text-sm">{d.clinic}</p>
            <div className="mt-3">
              <Link to={`/booking/${d.id}`} className="bg-blue-600 text-white px-3 py-1 rounded">Book</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
