import { useEffect, useState } from 'react'
import API from '../api'

export default function PatientDashboard(){
  const [appointments, setAppointments] = useState([])
  useEffect(()=>{ API.get('/appointments').then(r=> setAppointments(r.data.appointments)).catch(()=>{}) },[])

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Your Appointments</h1>
      <div className="space-y-3">
        {appointments.map(a=> (
          <div key={a.id} className="bg-white p-3 rounded shadow">
            <div className="flex justify-between">
              <div>
                <div className="font-semibold">Dr. {a.doctor_name}</div>
                <div className="text-sm">{new Date(a.scheduled_at).toLocaleString()}</div>
              </div>
              <div className="text-sm">{a.status}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
