import { useEffect, useState } from 'react'
import API from '../api'

export default function DoctorDashboard(){
  const [appointments, setAppointments] = useState([])
  useEffect(()=>{ API.get('/appointments').then(r=> setAppointments(r.data.appointments)).catch(()=>{}) },[])

  async function updateStatus(id, status){
    await API.patch(`/appointments/${id}/status`, { status })
    setAppointments(prev => prev.map(p=> p.id === id ? { ...p, status } : p))
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Doctor — Appointments</h1>
      <div className="space-y-3">
        {appointments.map(a=> (
          <div key={a.id} className="bg-white p-3 rounded shadow flex justify-between items-center">
            <div>
              <div className="font-semibold">{a.patient_name}</div>
              <div className="text-sm">{new Date(a.scheduled_at).toLocaleString()}</div>
            </div>
            <div className="space-x-2">
              <button onClick={()=>updateStatus(a.id,'accepted')} className="px-3 py-1 bg-green-600 text-white rounded">Accept</button>
              <button onClick={()=>updateStatus(a.id,'rejected')} className="px-3 py-1 bg-red-600 text-white rounded">Reject</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
