import { Link, useNavigate } from 'react-router-dom'

export default function Header(){
  const navigate = useNavigate()
  const token = localStorage.getItem('token')
  const user = localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')) : null

  function logout(){
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    navigate('/')
    window.location.reload()
  }

  return (
    <header className="bg-white shadow">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="font-bold text-xl">TeleMed</Link>
        <nav className="space-x-4">
          {!token && <Link to="/login" className="hover:underline">Login</Link>}
          {!token && <Link to="/signup" className="bg-blue-600 text-white px-3 py-1 rounded">Sign up</Link>}
          {token && <span className="mr-4">Welcome, {user?.name}</span>}
          {token && <button onClick={logout} className="bg-red-500 text-white px-3 py-1 rounded">Logout</button>}
        </nav>
      </div>
    </header>
  )
}
