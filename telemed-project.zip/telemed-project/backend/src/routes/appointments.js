const express = require('express')
const router = express.Router()
const db = require('../db')
const auth = require('../middleware/authMiddleware')

// Create appointment (patient)
router.post('/', auth, async (req,res)=>{
  try{
    const { doctor_id, scheduled_at, duration_minutes=30, notes='' } = req.body
    const patient_id = req.user.id
    const q = `INSERT INTO appointments (patient_id, doctor_id, scheduled_at, duration_minutes, notes)
               VALUES ($1,$2,$3,$4,$5) RETURNING *`
    const result = await db.query(q, [patient_id, doctor_id, scheduled_at, duration_minutes, notes])
    res.json({ appointment: result.rows[0] })
  }catch(err){
    console.error(err)
    res.status(500).json({ message: 'Server error' })
  }
})

// Get appointments for user
router.get('/', auth, async (req,res)=>{
  try{
    const userId = req.user.id
    const q = `SELECT a.*, p.name as patient_name, duser.name as doctor_name
               FROM appointments a
               LEFT JOIN users p ON p.id = a.patient_id
               LEFT JOIN users duser ON duser.id = a.doctor_id
               WHERE a.patient_id = $1 OR a.doctor_id = $1 ORDER BY a.scheduled_at DESC`
    const result = await db.query(q, [userId])
    res.json({ appointments: result.rows })
  }catch(err){
    console.error(err)
    res.status(500).json({ message: 'Server error' })
  }
})

// Update appointment status (doctor)
router.patch('/:id/status', auth, async (req,res)=>{
  try{
    const { status } = req.body
    const id = req.params.id
    const q = `UPDATE appointments SET status=$1 WHERE id=$2 RETURNING *`
    const result = await db.query(q, [status, id])
    res.json({ appointment: result.rows[0] })
  }catch(err){
    console.error(err)
    res.status(500).json({ message: 'Server error' })
  }
})

module.exports = router
