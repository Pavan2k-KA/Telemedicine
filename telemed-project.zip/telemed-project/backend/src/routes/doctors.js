const express = require('express')
const router = express.Router()
const db = require('../db')

// List doctors with profile
router.get('/', async (req,res)=>{
  try{
    const q = `SELECT u.id, u.name, u.email, d.specialization, d.qualifications, d.years_experience, d.clinic
               FROM users u JOIN doctors d ON d.user_id = u.id`
    const result = await db.query(q)
    res.json({ doctors: result.rows })
  }catch(err){
    console.error(err)
    res.status(500).json({ message: 'Server error' })
  }
})

module.exports = router
